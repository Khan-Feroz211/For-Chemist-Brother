#!/bin/bash

# Chemistry Lab Pro - GitHub Codespace Setup Script
# This script automatically sets up and deploys the Chemistry Lab Pro application

echo "🧪 Chemistry Lab Pro - Production Setup"
echo "========================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Step 1: Check if we're in a git repository
echo -e "${BLUE}[1/6]${NC} Checking environment..."
if [ ! -d ".git" ]; then
    echo -e "${YELLOW}Not in a git repository. Initializing...${NC}"
    git init
    git config user.name "Khan Feroz"
    git config user.email "your-email@example.com"
fi
echo -e "${GREEN}✓${NC} Environment ready"
echo ""

# Step 2: Copy the main application file
echo -e "${BLUE}[2/6]${NC} Setting up application files..."
if [ -f "chemistry-lab-production.html" ]; then
    cp chemistry-lab-production.html index.html
    echo -e "${GREEN}✓${NC} Main application file created: index.html"
else
    echo -e "${RED}✗${NC} Error: chemistry-lab-production.html not found!"
    echo -e "${YELLOW}Please ensure the production file is in the current directory.${NC}"
    exit 1
fi
echo ""

# Step 3: Create necessary documentation files
echo -e "${BLUE}[3/6]${NC} Creating documentation..."

# Create README.md (truncated version for script)
cat > README.md << 'READMEEOF'
# 🧪 Chemistry Lab Pro - Production Edition

A comprehensive, AI-powered chemistry toolkit for students and educators.

## 🚀 Quick Start in GitHub Codespaces

1. **Open in Codespaces** (automatically done if you're seeing this)
2. **Run Setup:**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```
3. **Access the app** - Click "Open in Browser" when prompted

## ✨ Features

- 🎨 Molecular Structure Visualizer (2D/3D)
- ⚖️ AI Equation Balancer (100+ reactions)
- 🔢 Molar Mass Calculator (118 elements)
- 🤖 AI Chemistry Predictor
- ⚛️ Complete Periodic Table
- ⚠️ Chemical Safety Database

## 🔒 Security

- XSS Protection
- Input Validation
- Rate Limiting
- CSP Headers
- Enterprise-grade security

## 📖 Usage

Simply open `index.html` in any modern browser. No installation required!

## 🛡️ Safety Notice

Educational purposes only. Always follow proper lab safety protocols.

## 📄 License

MIT License - Free for personal and commercial use

## 👨‍💻 Author

Created with ❤️ by Khan Feroz for my brother and all chemistry enthusiasts!
READMEEOF

echo -e "${GREEN}✓${NC} README.md created"

# Create LICENSE file
cat > LICENSE << 'LICENSEEOF'
MIT License

Copyright (c) 2025 Khan Feroz

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
LICENSEEOF

echo -e "${GREEN}✓${NC} LICENSE created"

# Create .gitignore
cat > .gitignore << 'GITIGNOREEOF'
# OS Files
.DS_Store
Thumbs.db
desktop.ini

# Editor files
.vscode/
.idea/
*.swp
*.swo
*~

# Logs
*.log
npm-debug.log*

# Temporary files
*.tmp
.temp/

# Build files (if any)
dist/
build/
GITIGNOREEOF

echo -e "${GREEN}✓${NC} .gitignore created"
echo ""

# Step 4: Create GitHub Pages deployment configuration
echo -e "${BLUE}[4/6]${NC} Configuring GitHub Pages..."

# Create .github directory structure
mkdir -p .github/workflows

# Create GitHub Actions workflow for automatic deployment
cat > .github/workflows/deploy.yml << 'WORKFLOWEOF'
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      
      - name: Setup Pages
        uses: actions/configure-pages@v4
      
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: '.'
      
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
WORKFLOWEOF

echo -e "${GREEN}✓${NC} GitHub Actions workflow created"
echo ""

# Step 5: Create development server configuration
echo -e "${BLUE}[5/6]${NC} Setting up development server..."

# Create a simple Python HTTP server script
cat > serve.py << 'PYTHONEOF'
#!/usr/bin/env python3
import http.server
import socketserver
import webbrowser
import os
from pathlib import Path

PORT = 8000

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Add security headers
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-XSS-Protection', '1; mode=block')
        self.send_header('Content-Security-Policy', "default-src 'self' https://unpkg.com; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline'")
        super().end_headers()

def start_server():
    Handler = MyHTTPRequestHandler
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"\n🧪 Chemistry Lab Pro - Development Server")
        print(f"=" * 50)
        print(f"✓ Server running at: http://localhost:{PORT}")
        print(f"✓ Open in browser: http://localhost:{PORT}/index.html")
        print(f"\n💡 Press Ctrl+C to stop the server\n")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n👋 Server stopped. Thanks for using Chemistry Lab Pro!")
            pass

if __name__ == "__main__":
    start_server()
PYTHONEOF

chmod +x serve.py

echo -e "${GREEN}✓${NC} Development server configured"
echo ""

# Step 6: Git operations
echo -e "${BLUE}[6/6]${NC} Preparing Git repository..."

# Add all files
git add .

# Create initial commit if needed
if ! git rev-parse HEAD > /dev/null 2>&1; then
    git commit -m "🧪 Initial commit: Chemistry Lab Pro - Production Edition

Features:
- Molecular Structure Visualizer (2D/3D)
- AI Equation Balancer (100+ reactions)
- Molar Mass Calculator (118 elements)
- AI Chemistry Predictor
- Complete Periodic Table
- Chemical Safety Database

Security:
- XSS Protection
- Input Validation
- Rate Limiting
- Enterprise-grade security

Ready for production deployment!"
    echo -e "${GREEN}✓${NC} Initial commit created"
else
    echo -e "${YELLOW}⚠${NC} Repository already has commits"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}✓ Setup Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${BLUE}📋 Next Steps:${NC}"
echo ""
echo -e "  ${YELLOW}1. Test Locally:${NC}"
echo -e "     ${GREEN}python3 serve.py${NC}"
echo -e "     Then open http://localhost:8000"
echo ""
echo -e "  ${YELLOW}2. Push to GitHub:${NC}"
echo -e "     ${GREEN}git remote add origin https://github.com/Khan-Feroz211/For-Chemist-Brother.git${NC}"
echo -e "     ${GREEN}git branch -M main${NC}"
echo -e "     ${GREEN}git push -u origin main${NC}"
echo ""
echo -e "  ${YELLOW}3. Enable GitHub Pages:${NC}"
echo -e "     - Go to repository Settings"
echo -e "     - Navigate to Pages section"
echo -e "     - Select 'GitHub Actions' as source"
echo -e "     - Your site will be live at:"
echo -e "     ${GREEN}https://khan-feroz211.github.io/For-Chemist-Brother/${NC}"
echo ""
echo -e "${BLUE}🎉 Your Chemistry Lab Pro is ready to deploy!${NC}"
echo ""
echo -e "${YELLOW}💡 Pro Tips:${NC}"
echo -e "   • The app works offline after first load"
echo -e "   • All 118 elements are supported"
echo -e "   • 100+ balanced equations included"
echo -e "   • AI features work completely client-side"
echo -e "   • Enterprise-grade security implemented"
echo ""
echo -e "${BLUE}📖 For detailed documentation, see README.md${NC}"
echo ""

